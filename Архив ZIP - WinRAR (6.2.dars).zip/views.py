from django.http import HttpResponse


def homepage_view(request):
    response="<h1>Ravshanov Baahrombek</h1>"
    response+="<h2>Ravshanov Baahrombek</h2>"
    response+="<h3>Ravshanov Baahrombek</h3>"
    response+="<h4>Ravshanov Baahrombek</h4>"
    return HttpResponse(responce)