from django.http import HttpResponse

def page1(request):
    html = """
        <h1>Page 1</h1>
        <p>Bu birinchi sahifa. Django haqida umumiy tushuncha berilgan.</p>
        <a href='/page2/'>Keyingi sahifa →</a>
    """
    return HttpResponse(html)

def page2(request):
    html = """
        <h1>Page 2</h1>
        <p>Bu sahifada URL va View haqida ma'lumotlar bor.</p>
        <a href='/page1/'>← Oldingi sahifa</a> |
        <a href='/page3/'>Keyingi sahifa →</a>
    """
    return HttpResponse(html)

def page3(request):
    html = """
        <h1>Page 3</h1>
        <p>Bu yerda Template'lar va ularni ishlatmaslik haqida gap boradi.</p>
        <a href='/page2/'>← Oldingi sahifa</a> |
        <a href='/page4/'>Keyingi sahifa →</a>
    """
    return HttpResponse(html)

def page4(request):
    html = """
        <h1>Page 4</h1>
        <p>Bu sahifada Forms va foydalanuvchi bilan ishlash haqida so'z boradi.</p>
        <a href='/page3/'>← Oldingi sahifa</a> |
        <a href='/page5/'>Keyingi sahifa →</a>
    """
    return HttpResponse(html)

def page5(request):
    html = """
        <h1>Page 5</h1>
        <p>Bu so'nggi sahifa. Django loyihasini deployment qilish haqida ma'lumot.</p>
        <a href='/page4/'>← Oldingi sahifa</a>
    """
    return HttpResponse(html)